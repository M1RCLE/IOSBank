public enum ButtonStyle {
    case primary
    case secondary
    case outlined
    case text
}
