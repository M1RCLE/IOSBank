public enum TextInputStyle {
    case standard
    case outlined
    case error
}
