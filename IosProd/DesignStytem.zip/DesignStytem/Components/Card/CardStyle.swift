public enum CardStyle {
    case elevated
    case outlined
    case filled
}
